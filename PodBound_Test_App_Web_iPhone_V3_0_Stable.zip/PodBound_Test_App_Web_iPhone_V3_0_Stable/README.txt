PodBound Test App Web/iPhone V3.0 Stable

Stability build:
- Removed generated beep/boop music engine from V2.5.
- Added proper background music support via your own royalty-free audio file.
- Choose an MP3/M4A/WAV file, then tap Play Music.
- Hardcoded dropdown options for mobile/iPhone reliability.
- Safer startup for local iPhone/browser use.
- Keeps End Turn flow, AI mode, AI vs AI, auto Environment advance, Dairy Cow cap 2, Clown Shift, save history, random everything, winner summary, and CSV export.

Important iPhone notes:
- Mobile Safari requires a user tap before audio can play.
- If opening local files on iPhone is weird, host this index.html privately or open it from Files/Safari.
